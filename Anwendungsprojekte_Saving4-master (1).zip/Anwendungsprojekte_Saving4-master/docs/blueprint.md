# **App Name**: CostWise Dashboard

## Core Features:

- KPI Display: Displays key performance indicators (KPIs) related to cost savings, such as planned savings, realized savings, average ROI, and completed actions.
- Data Visualization: Presents data visualizations, including a bar chart for planned vs. realized savings by department and a line chart for realized savings over time.
- Measures Table: Allows users to view and filter a table of cost-saving measures, including details such as description, department, cost center, planned savings, realized savings, status, and ROI.
- Basic Filtering: Implements basic filtering for the measures table, allowing users to filter by department.

## Style Guidelines:

- Primary color: Soft blue (#7CB5EC) to represent trust and stability, commonly associated with financial data.
- Background color: Very light gray (#F4F6F8) to create a clean and modern look, providing a neutral backdrop for data display.
- Accent color: Light green (#82E0AA) to highlight positive metrics, like 'Achieved' status. It contrasts against the primary blue to draw attention to these elements.
- Use a clean, sans-serif font (e.g., 'Roboto', 'Open Sans', or a system-default sans-serif) for readability and a modern aesthetic.
- Employ a grid-based layout or Flexbox to ensure the dashboard is responsive and well-organized.
- Use simple, consistent icons for chart types (bar, line), filters, and table-related actions to aid visual understanding and navigation.