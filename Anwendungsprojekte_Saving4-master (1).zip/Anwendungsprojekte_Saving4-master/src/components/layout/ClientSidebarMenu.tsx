
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarGroup,
} from '@/components/ui/sidebar';
import type { ElementType } from 'react';
import { 
  Factory, 
  FlaskConical, 
  Megaphone, 
  Cog, 
  Users, 
  Landmark, 
  ShoppingCart, 
  Truck, 
  Handshake, 
  Briefcase, 
  Layers,
  Building
} from 'lucide-react';
import type { SupabaseClient } from '@supabase/supabase-js'; // Import SupabaseClient type

interface ClientSidebarMenuProps {
  departments: string[];
  supabase: SupabaseClient | null; // Add supabase prop
}

const departmentIconMap: Record<string, ElementType> = {
  'produktion': Factory,
  'fertigung': Factory,
  'forschung': FlaskConical,
  'entwicklung': FlaskConical,
  'marketing': Megaphone,
  'it': Cog,
  'edv': Cog,
  'hr': Users,
  'personal': Users,
  'human resources': Users,
  'finanzen': Landmark,
  'controlling': Landmark,
  'buchhaltung': Landmark,
  'einkauf': ShoppingCart,
  'beschaffung': ShoppingCart,
  'logistik': Truck,
  'vertrieb': Handshake,
  'sales': Handshake,
  'management': Briefcase,
  'geschäftsführung': Briefcase,
  'verwaltung': Building,
};

const DefaultIcon = Layers;

export default function ClientSidebarMenu({ departments, supabase }: ClientSidebarMenuProps) {
  const pathname = usePathname();

  // If supabase client is not yet available, or no departments, show loading or empty state
  if (!supabase || departments.length === 0) {
    // Optionally, render a loading skeleton or a message
    return (
        <SidebarMenu>
            <SidebarGroup>
                <SidebarMenuItem>
                    <SidebarMenuButton disabled>
                        <Layers />
                         <span className="group-data-[collapsible=icon]:hidden">Lade Bereiche...</span>
                    </SidebarMenuButton>
                </SidebarMenuItem>
            </SidebarGroup>
        </SidebarMenu>
    );
  }

  return (
    <SidebarMenu>
      <SidebarGroup>
        {departments.map((deptName) => {
          const slug = deptName.toLowerCase().replace(/\s+/g, '-'); 
          const href = `/bereiche/${slug}`;
          const lowerDeptName = deptName.toLowerCase();
          const IconComponent = departmentIconMap[lowerDeptName] || DefaultIcon;

          return (
            <SidebarMenuItem key={slug}>
              <SidebarMenuButton
                asChild
                isActive={pathname.startsWith(href)}
                tooltip={{ children: `Bereich ${deptName}`, side: "right", align: "center" }}
              >
                <Link href={href}>
                  <IconComponent />
                  <span className="group-data-[collapsible=icon]:hidden">{deptName}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          );
        })}
      </SidebarGroup>
    </SidebarMenu>
  );
}
