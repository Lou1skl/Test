
"use client";

import type { FC } from 'react';
import { Area, AreaChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { ChartContainer, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { formatCurrency, parseNumber } from '@/data/dashboard-data'; 
import { format, startOfMonth, isValid as isValidDate } from 'date-fns'; 
import { de } from 'date-fns/locale';
import type { Measure } from '@/types'; 


interface FinancialTrendChartProps {
  measures: Measure[] | null;
}

const FinancialTrendChart: FC<FinancialTrendChartProps> = ({ measures }) => {
  if (!measures || measures.length === 0) {
    return <div className="flex items-center justify-center h-full min-h-[300px] text-muted-foreground p-4">Keine Daten für dieses Diagramm verfügbar. Prüfen Sie die 'massnahmen'-Datenquelle.</div>;
  }

  const monthlySavings = measures.reduce((acc, measure) => {
    try {
      const dateString = measure.Letztes_Update; // Changed from measure['Letztes Update']
      if (!dateString || typeof dateString !== 'string') {
        return acc;
      }
      const date = new Date(dateString); 
      if (!isValidDate(date)) { 
          return acc;
      }
      const monthKey = format(startOfMonth(date), 'yyyy-MM');
      const realizedSavingsValue = parseNumber(measure.Realisierte_Einsparung);
      acc[monthKey] = (acc[monthKey] || 0) + realizedSavingsValue;
    } catch (e) {
      // Error processing date, skip this measure
    }
    return acc;
  }, {} as Record<string, number>);

  const chartData = Object.entries(monthlySavings)
    .map(([monthKey, savings]) => {
      const dateFromKey = new Date(`${monthKey}-01T00:00:00`); // Ensure it's treated as local time / specific time for consistency
       if (!isValidDate(dateFromKey)) { 
        return null; 
      }
      return {
        dateLabel: format(dateFromKey, "MMM ''yy", { locale: de }), 
        realisierteEinsparung: savings,
        fullDate: format(dateFromKey, 'MMMM yyyy', { locale: de }) 
      };
    })
    .filter(item => item !== null && typeof item.realisierteEinsparung === 'number' && item.realisierteEinsparung >= 0) // Allow 0 for chart rendering
    // @ts-ignore next-line - sorting by parsed date
    .sort((a, b) => new Date(a!.fullDate).getTime() - new Date(b!.fullDate).getTime());


  if (chartData.length === 0) {
    return <div className="flex items-center justify-center h-full min-h-[300px] text-muted-foreground p-4">Für dieses Diagramm konnten keine relevanten Datenpunkte aus den Maßnahmen generiert werden (z.B. alle realisierten Einsparungen sind 0 oder Datumsangaben fehlen/sind ungültig).</div>;
  }
  
  const chartConfig = {
    realisierteEinsparung: {
      label: "Realisierte Einsparung",
      color: "hsl(var(--chart-1))", 
    },
  } satisfies ChartConfig;

  return (
    <ChartContainer config={chartConfig} className="h-full w-full">
      <ResponsiveContainer width="100%" height={300}>
        <AreaChart data={chartData} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
          <defs>
            <linearGradient id="colorRealisierteEinsparungTrend" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.8}/>
              <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0.1}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border) / 0.5)" />
          <XAxis 
            dataKey="dateLabel" 
            tickLine={false} 
            axisLine={false} 
            tickMargin={10} 
            fontSize={12}
            stroke="hsl(var(--muted-foreground))"
            interval={chartData.length > 10 ? Math.floor(chartData.length / 10) : 0} 
          />
          <YAxis 
            tickFormatter={(value) => `${value / 1000}k`} 
            tickLine={false} 
            axisLine={false} 
            tickMargin={5}
            fontSize={12}
            stroke="hsl(var(--muted-foreground))"
          />
          <Tooltip
            content={
              <ChartTooltipContent
                formatter={(value, name, props) => (
                  <div className="flex items-center">
                    <span className="w-2.5 h-2.5 rounded-full mr-2" style={{ backgroundColor: chartConfig.realisierteEinsparung.color }}></span>
                    <span className="capitalize mr-2 text-muted-foreground">{chartConfig.realisierteEinsparung.label}:</span>
                    <span className="font-semibold">{formatCurrency(value as number)}</span>
                  </div>
                )}
                labelFormatter={(label, payload) => payload?.[0]?.payload.fullDate || label}
                indicator="dot"
                cursor={{ stroke: "hsl(var(--primary))", strokeWidth: 1.5 }}
              />
            }
          />
          <Legend 
            verticalAlign="top" 
            height={40} 
            iconSize={10}
            wrapperStyle={{fontSize: "12px"}}
          />
          <Area 
            type="monotone" 
            dataKey="realisierteEinsparung" 
            stroke="hsl(var(--chart-1))" 
            fillOpacity={1} 
            fill="url(#colorRealisierteEinsparungTrend)" 
            strokeWidth={2.5} 
            name={chartConfig.realisierteEinsparung.label}
            dot={{ r: 4, strokeWidth: 1, fill: "hsl(var(--background))" }} 
            activeDot={{r: 6, strokeWidth: 1.5, fill: "hsl(var(--background))" }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
};

export default FinancialTrendChart;
