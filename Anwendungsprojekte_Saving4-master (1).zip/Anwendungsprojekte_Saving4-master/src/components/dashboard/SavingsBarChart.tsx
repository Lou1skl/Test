
"use client";

import type { FC } from 'react';
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { ChartContainer, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { formatCurrency, parseNumber } from '@/data/dashboard-data'; // Import parseNumber
import type { Measure } from '@/types'; 

interface RevenueExpenseBarChartProps {
  measures: Measure[] | null;
}

const RevenueExpenseBarChart: FC<RevenueExpenseBarChartProps> = ({ measures }) => {
  if (!Array.isArray(measures) || measures.length === 0) {
    return <div className="flex items-center justify-center h-full min-h-[300px] text-muted-foreground p-4">Keine Daten für dieses Diagramm verfügbar. Prüfen Sie die 'massnahmen'-Datenquelle.</div>;
  }

  const processedData = measures.reduce((acc, measure) => {
    const department = measure.Department || 'Unbekannt';
    if (!acc[department]) {
      acc[department] = { department, geplante: 0, realisierte: 0 };
    }
    // Use parseNumber for robust conversion
    const geplanteValue = parseNumber(measure.Geplante_Einsparung);
    const realisierteValue = parseNumber(measure.Realisierte_Einsparung);
    
    acc[department].geplante += geplanteValue;
    acc[department].realisierte += realisierteValue;
    return acc;
  }, {} as Record<string, { department: string; geplante: number; realisierte: number }>);

  const chartData = Object.values(processedData).filter(d => d.geplante > 0 || d.realisierte > 0);

  if (chartData.length === 0) {
    return <div className="flex items-center justify-center h-full min-h-[300px] text-muted-foreground p-4">Für dieses Diagramm konnten keine relevanten Datenpunkte aus den Maßnahmen generiert werden (z.B. alle Einsparungen sind 0 oder Abteilungen fehlen).</div>;
  }

  const chartConfig = {
    geplante: {
      label: "Geplante Einsparung",
      color: "hsl(var(--chart-2))", 
    },
    realisierte: {
      label: "Realisierte Einsparung",
      color: "hsl(var(--chart-1))", 
    },
  } satisfies ChartConfig;

  return (
    <ChartContainer config={chartConfig} className="h-full w-full">
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={chartData} margin={{ top: 5, right: 20, left: 10, bottom: 40 }} barGap={4} barCategoryGap="20%"> {/* Increased bottom margin */}
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border) / 0.5)" />
          <XAxis 
            dataKey="department" 
            tickLine={false} 
            axisLine={false} 
            tickMargin={10} 
            fontSize={12}
            stroke="hsl(var(--muted-foreground))"
            interval={0} 
            angle={-30} 
            textAnchor="end" 
            height={60} // Added height to XAxis to ensure space for angled labels
          />
          <YAxis 
            tickFormatter={(value) => `${value / 1000}k`} 
            tickLine={false} 
            axisLine={false} 
            tickMargin={5}
            fontSize={12}
            stroke="hsl(var(--muted-foreground))"
          />
          <Tooltip
            content={<ChartTooltipContent 
              formatter={(value) => formatCurrency(value as number)} 
              indicator="dot"
              cursor={{ fill: "hsl(var(--muted) / 0.3)" }}
            />}
          />
          <Legend 
            verticalAlign="top" 
            height={40} 
            iconSize={10}
            wrapperStyle={{fontSize: "12px"}}
          />
          <Bar dataKey="realisierte" fill="var(--color-realisierte)" radius={[4, 4, 0, 0]} name="Realisierte Einsparung" />
          <Bar dataKey="geplante" fill="var(--color-geplante)" radius={[4, 4, 0, 0]} name="Geplante Einsparung" />
        </BarChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
};

export default RevenueExpenseBarChart;
