import type { FC } from 'react';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';

interface PageHeaderProps {
  title: string;
  showExportButton?: boolean;
}

const PageHeader: FC<PageHeaderProps> = ({ title, showExportButton = false }) => {
  return (
    <header className="mb-8 pb-4 border-b border-border">
      <div className="flex flex-col sm:flex-row justify-between items-center">
        <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4 sm:mb-0">
          {title}
        </h1>
        {showExportButton && (
          <Button variant="default" size="lg">
            <Download size={20} className="mr-2" />
            Daten exportieren
          </Button>
        )}
      </div>
    </header>
  );
};

export default PageHeader;
