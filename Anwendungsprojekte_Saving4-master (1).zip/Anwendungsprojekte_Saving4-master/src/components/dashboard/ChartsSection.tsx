
import type { FC } from 'react';
import ChartCard from './ChartCard';
import RevenueExpenseBarChart from './SavingsBarChart'; // This name might be slightly off now, but it visualizes planned vs realized
import FinancialTrendChart from './SavingsLineChart';
import ExpenseCategoryDonutChart from './ExpenseCategoryDonutChart';
import { BarChart3, LineChart as LineChartIcon, PieChart } from 'lucide-react';
import type { Measure } from '@/types'; // Import centralized type

interface ChartsSectionProps {
  measures: Measure[] | null;
}

const ChartsSection: FC<ChartsSectionProps> = ({ measures }) => {
  // Individual chart components will handle the "no data" state themselves.

  return (
    <section className="grid grid-cols-1 gap-6 lg:grid-cols-2 xl:grid-cols-3">
      <ChartCard title="Geplante vs. Realisierte Einsparungen (nach Abt.)" icon={<BarChart3 size={24} />}>
        <RevenueExpenseBarChart measures={measures} />
      </ChartCard>
      <ChartCard title="Realisierte Einsparungen über Zeit" icon={<LineChartIcon size={24} />}>
        <FinancialTrendChart measures={measures} />
      </ChartCard>
      <ChartCard title="Realisierte Einsparungen nach Abteilung" icon={<PieChart size={24} />} className="lg:col-span-2 xl:col-span-1">
        <ExpenseCategoryDonutChart measures={measures} />
      </ChartCard>
    </section>
  );
};

export default ChartsSection;
