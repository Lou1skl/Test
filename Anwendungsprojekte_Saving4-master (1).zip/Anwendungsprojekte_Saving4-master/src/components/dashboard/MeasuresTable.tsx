
import type { FC } from 'react';
import { ListChecks } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableHead,
  TableHeader,
  TableRow,
  TableCell,
} from "@/components/ui/table";

interface Measure {
  'Maßnahmen-ID': string;
  'Maßnahmenbeschreibung': string;
  'Kostenstelle': number;
  'Geplante Einsparung (€)': number;
  'Realisierte Einsparung (€)': number;
  'Status': string;
  'Letztes Update': string;
  'Erfüllungsgrad (%)': number;
  'Time-to-Saving (Tage)': number;
  'ROI-Schätzung (%)': number;
  'Automatisierter KPI-Status': string;
  'Department': string;
}

interface MeasuresTableProps {
  measures: Measure[] | null;
}

const MeasuresTable: FC<MeasuresTableProps> = ({ measures }) => {

  if (!measures || measures.length === 0) {
    return (
      <Card className="shadow-medium rounded-lg">
        <CardHeader>
          <CardTitle className="flex items-center text-xl font-semibold text-foreground">
            <ListChecks size={24} className="mr-3 text-primary" />
            Maßnahmenübersicht
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center text-muted-foreground p-8">
            Keine Maßnahmen in der Datenbank gefunden, um die Tabelle anzuzeigen.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-medium rounded-lg">
      <CardHeader className="flex flex-col md:flex-row items-start md:items-center justify-between">
        <CardTitle className="flex items-center text-xl font-semibold text-foreground mb-4 md:mb-0">
          <ListChecks size={24} className="mr-3 text-primary" />
          Maßnahmenübersicht
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Maßnahmen-ID</TableHead>
              <TableHead>Maßnahmenbeschreibung</TableHead>
              <TableHead>Kostenstelle</TableHead>
              <TableHead>Geplante Einsparung (€)</TableHead>
              <TableHead>Realisierte Einsparung (€)</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Letztes Update</TableHead>
              <TableHead>Erfüllungsgrad (%)</TableHead>
              <TableHead>Time-to-Saving (Tage)</TableHead>
              <TableHead>ROI-Schätzung (%)</TableHead>
              <TableHead>Automatisierter KPI-Status</TableHead>
              <TableHead>Department</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {measures.map((measure) => (
              <TableRow key={measure['Maßnahmen-ID']}>
                <TableCell className="font-medium">{measure['Maßnahmen-ID'] ?? '-'}</TableCell>
                <TableCell>{measure['Maßnahmenbeschreibung'] ?? '-'}</TableCell>
                <TableCell>{measure['Kostenstelle'] ?? '-'}</TableCell>
                <TableCell>{measure['Geplante Einsparung (€)'] ?? '-'}</TableCell>
                <TableCell>{measure['Realisierte Einsparung (€)'] ?? '-'}</TableCell>
                <TableCell>{measure['Status'] ?? '-'}</TableCell>
                <TableCell>{measure['Letztes Update'] ?? '-'}</TableCell>
                <TableCell>{measure['Erfüllungsgrad (%)'] ?? '-'}</TableCell>
                <TableCell>{measure['Time-to-Saving (Tage)'] ?? '-'}</TableCell>
                <TableCell>{measure['ROI-Schätzung (%)'] ?? '-'}</TableCell>
                <TableCell>{measure['Automatisierter KPI-Status'] ?? '-'}</TableCell>
                <TableCell>{measure['Department'] ?? '-'}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default MeasuresTable;
