
import type { FC } from 'react';
import KpiCard from './KpiCard';
import type { Measure } from '@/types';
import { parseNumber } from '@/data/dashboard-data';

interface KpiSectionProps {
  measures: Measure[] | null; 
}

// Helper function to format currency for KPIs
const formatCurrencyKPI = (value: number): string => {
  return new Intl.NumberFormat('de-DE', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

const KpiSection: FC<KpiSectionProps> = ({ measures: measuresDataArray }) => {
  if (!Array.isArray(measuresDataArray) || measuresDataArray.length === 0) {
    return (
      <section className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <div className="sm:col-span-2 lg:col-span-4 text-center p-8 text-muted-foreground bg-card shadow-medium rounded-lg">
          Keine KPI-Daten verfügbar. Bitte überprüfen Sie, ob die Tabelle 'massnahmen' in der Datenbank existiert und Daten enthält, oder ob RLS-Richtlinien den Zugriff verhindern.
        </div>
      </section>
    );
  }

  const measures = measuresDataArray;

  // Calculate KPIs
  const totalPlannedSavings = measures.reduce((sum, measure) => sum + parseNumber(measure.Geplante_Einsparung), 0);
  const totalRealizedSavings = measures.reduce((sum, measure) => sum + parseNumber(measure.Realisierte_Einsparung), 0);

  // Filter for measures with valid numeric Erfuellungsgrad
  const numericErfuellungsgrade = measures
    .map(measure => measure.Erfuellungsgrad)
    .filter(ef => typeof ef === 'number');

  // Calculate sum of valid numeric Erfuellungsgrad values
  const totalFulfillmentSum = numericErfuellungsgrade.reduce((sum, ef) => sum + ef, 0);
  
  // Calculate average only based on measures with valid numeric Erfuellungsgrad
  const averageFulfillmentRate = numericErfuellungsgrade.length > 0 
    ? totalFulfillmentSum / numericErfuellungsgrade.length 
    : 0;

  // Count completed measures based on Erfuellungsgrad >= 100
  const completedMeasuresCount = measures.filter(measure => typeof measure.Erfuellungsgrad === 'number' && measure.Erfuellungsgrad >= 100).length;
  const totalMeasuresCount = measures.length; // Total measures are dynamic from the data

  return (
    <section className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
      <KpiCard title="Gesamte Geplante Einsparung" value={formatCurrencyKPI(totalPlannedSavings)} bgColorClass="kpi-bg-blue" />
      <KpiCard title="Gesamte Realisierte Einsparung" value={formatCurrencyKPI(totalRealizedSavings)} bgColorClass="kpi-bg-green" />
      <KpiCard title="Durchschnittl. Erfüllungsgrad" value={`${averageFulfillmentRate.toFixed(1)} %`} bgColorClass="kpi-bg-purple" />
      <KpiCard title="Abgeschlossene Maßnahmen" value={`${completedMeasuresCount} / ${totalMeasuresCount}`} bgColorClass="kpi-bg-light-blue" />
    </section>
  );
};

export default KpiSection;
