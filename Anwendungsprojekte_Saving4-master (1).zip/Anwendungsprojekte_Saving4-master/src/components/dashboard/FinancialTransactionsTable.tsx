
'use client';

import type { FC } from 'react';
import { useState, useMemo } from 'react';
import { ListChecks, Filter, CalendarDays, ChevronDown } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableHead,
  TableHeader,
  TableRow,
  TableCell,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuItem,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import type { Measure } from '@/types';
import { formatCurrency, parseNumber } from '@/data/dashboard-data';
import { subDays, isValid } from 'date-fns';

interface FinancialTransactionsTableProps {
  data: Measure[] | null;
}

type MeasureStatus = "Abgeschlossen" | "In Bearbeitung" | "Geplant" | "Risiko" | "Über Plan" | "Im Rahmen" | "nicht erfuellt" | "erfuellt" | string;


const FinancialTransactionsTable: FC<FinancialTransactionsTableProps> = ({ data }) => {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedDateRange, setSelectedDateRange] = useState<string>('365');

  const transactions = data || [];

  const uniqueCategories = useMemo(() => {
    if (!transactions) return [];
    const departments = transactions.map(t => t.Department).filter(Boolean);
    return Array.from(new Set(departments as string[]));
  }, [transactions]);

  const dateRangeOptions = [
    { label: "Letzte 30 Tage", value: "30" },
    { label: "Letzte 90 Tage", value: "90" },
    { label: "Letzte 180 Tage", value: "180" },
    { label: "Letzte 365 Tage", value: "365" },
  ];

  const getStatusBadgeClass = (status: MeasureStatus) => {
    const lowerStatus = status?.toLowerCase();
    if (lowerStatus === 'nicht erfuellt') return "badge-neutral"; // Grau für "nicht erfuellt"
    if (lowerStatus === 'erfuellt') return "badge-success";     // Grün für "erfuellt"
    if (lowerStatus?.includes('abgeschlossen')) return "badge-success";
    if (lowerStatus?.includes('risiko')) return "badge-destructive";
    if (lowerStatus?.includes('über plan') || lowerStatus?.includes('ueber plan')) return "bg-blue-500 text-white"; // Blau für Status "Über Plan"
    if (lowerStatus?.includes('im rahmen')) return "badge-neutral"; // Grau für Status "Im Rahmen"
    if (lowerStatus?.includes('geplant')) return "badge-neutral";
    if (lowerStatus?.includes('in bearbeitung')) return "badge-warning";
    return "bg-secondary text-secondary-foreground";
  };

  const getKpiStatusBadgeClass = (kpiStatus: MeasureStatus) => {
    const lowerKpiStatus = kpiStatus?.toLowerCase();
    if (lowerKpiStatus?.includes('ueber plan')) { // Ensures "Ueber Plan" matches
      return "badge-warning"; // Gelb für KPI Status "Über Plan"
    }
    if (lowerKpiStatus?.includes('im rahmen')) {
      return "badge-success"; // Grün für KPI Status "Im Rahmen"
    }
    // Für andere KPI-Statuswerte die allgemeine Logik verwenden
    return getStatusBadgeClass(kpiStatus);
  };


  const filteredAndSortedTransactions = useMemo(() => {
    let filtered = transactions.filter(transaction => {
      const categoryMatch = selectedCategories.length === 0 || (transaction.Department && selectedCategories.includes(transaction.Department));

      let dateMatch = true;
      if (selectedDateRange !== 'all' && selectedDateRange) {
        const days = parseInt(selectedDateRange, 10);
        const cutoffDate = subDays(new Date(), days);
        try {
          const dateString = transaction.Letztes_Update;
          if (dateString && typeof dateString === 'string') {
            const transactionDate = new Date(dateString);
            if (!isValid(transactionDate)) {
               dateMatch = false;
            } else {
              dateMatch = transactionDate >= cutoffDate;
            }
          } else {
            dateMatch = false;
          }
        } catch (e) {
          dateMatch = false;
        }
      }
      return categoryMatch && dateMatch;
    });

    // Sort by Massnahmen_ID in ascending order
    filtered.sort((a, b) => {
      if (a.Massnahmen_ID && b.Massnahmen_ID) {
        return a.Massnahmen_ID.localeCompare(b.Massnahmen_ID);
      }
      if (a.Massnahmen_ID) return -1; // a comes first if b.Massnahmen_ID is null/undefined
      if (b.Massnahmen_ID) return 1;  // b comes first if a.Massnahmen_ID is null/undefined
      return 0; // no change if both are null/undefined
    });

    return filtered;
  }, [transactions, selectedCategories, selectedDateRange]);

  const handleCategoryToggle = (category: string) => {
    setSelectedCategories(prev =>
      prev.includes(category) ? prev.filter(c => c !== category) : [...prev, category]
    );
  };

  const getCategoryButtonText = () => {
    if (selectedCategories.length === 0) return "Alle Abteilungen";
    if (selectedCategories.length === 1) return selectedCategories[0];
    return `Abteilungen (${selectedCategories.length})`;
  };

  const getDateRangeButtonText = () => {
    const option = dateRangeOptions.find(opt => opt.value === selectedDateRange);
    return option ? option.label : "Datumsbereich";
  };

  if (!transactions) {
    return (
      <Card className="shadow-medium rounded-lg">
        <CardHeader>
          <CardTitle className="flex items-center text-xl font-semibold text-foreground">
            <ListChecks size={24} className="mr-3 text-primary" />
            Übersicht Maßnahmen
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center text-muted-foreground p-8">
            Daten werden geladen...
          </p>
        </CardContent>
      </Card>
    );
  }


  return (
    <Card className="shadow-medium rounded-lg">
      <CardHeader className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <CardTitle className="flex items-center text-xl font-semibold text-foreground">
          <ListChecks size={24} className="mr-3 text-primary" />
          Übersicht Maßnahmen
        </CardTitle>
        <div className="flex flex-wrap gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="bg-card hover:bg-muted">
                <Filter size={16} className="mr-2" />
                {getCategoryButtonText()}
                <ChevronDown size={16} className="ml-2" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Nach Abteilung filtern</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={() => setSelectedCategories([])}>
                Alle Abteilungen anzeigen
              </DropdownMenuItem>
              {uniqueCategories.map((category) => (
                <DropdownMenuCheckboxItem
                  key={category}
                  checked={selectedCategories.includes(category)}
                  onCheckedChange={() => handleCategoryToggle(category)}
                  onSelect={(e) => e.preventDefault()}
                >
                  {category}
                </DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="bg-card hover:bg-muted">
                <CalendarDays size={16} className="mr-2" />
                {getDateRangeButtonText()}
                <ChevronDown size={16} className="ml-2" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Datumsbereich auswählen</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuRadioGroup value={selectedDateRange} onValueChange={setSelectedDateRange}>
                {dateRangeOptions.map((option) => (
                  <DropdownMenuRadioItem key={option.value} value={option.value}>
                    {option.label}
                  </DropdownMenuRadioItem>
                ))}
              </DropdownMenuRadioGroup>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent>
        {filteredAndSortedTransactions.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Abteilung</TableHead>
                <TableHead>Letztes Update</TableHead>
                <TableHead>Realisierte Einsparung</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>KPI Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAndSortedTransactions.map((item) => (
                <TableRow key={item.Massnahmen_ID}>
                  <TableCell className="font-medium">{item.Massnahmen_ID ?? '-'}</TableCell>
                  <TableCell>{item.Department ?? '-'}</TableCell>
                  <TableCell>{item.Letztes_Update ?? '-'}</TableCell>
                  <TableCell>{formatCurrency(parseNumber(item.Realisierte_Einsparung) || 0)}</TableCell>
                  <TableCell>
                     <Badge className={cn("text-xs font-semibold py-1 px-2.5", getStatusBadgeClass(item.Status))} >
                        {item.Status ?? '-'}
                      </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={cn("text-xs font-semibold py-1 px-2.5", getKpiStatusBadgeClass(item.AutomatisierteKPIStatus))} >
                      {item.AutomatisierteKPIStatus ?? '-'}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <p className="text-center text-muted-foreground p-8">
            Keine Maßnahmen entsprechen den aktuellen Filterkriterien oder es sind keine Daten vorhanden.
          </p>
        )}
      </CardContent>
    </Card>
  );
};

export default FinancialTransactionsTable;

