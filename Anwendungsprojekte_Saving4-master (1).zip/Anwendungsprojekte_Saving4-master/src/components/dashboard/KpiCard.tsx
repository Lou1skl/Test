import type { FC } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { cn } from '@/lib/utils';

interface KpiCardProps {
  title: string;
  value: string | number; // Allow number or string for value
  bgColorClass?: string; // Optional background color class
}

const KpiCard: FC<KpiCardProps> = ({ title, value, bgColorClass }) => {
  return (
    <Card className={cn(
      "shadow-medium rounded-lg text-card-foreground overflow-hidden transform transition-all hover:scale-105 hover:shadow-lg",
      bgColorClass
    )}>
      <CardContent className="p-6 flex flex-col justify-between h-full">
        <h3 className="text-sm font-medium opacity-80 uppercase tracking-wider">{title}</h3>
        <div className="text-4xl font-bold mt-1">{value}</div>
      </CardContent>
    </Card>
  );
};

export default KpiCard;
