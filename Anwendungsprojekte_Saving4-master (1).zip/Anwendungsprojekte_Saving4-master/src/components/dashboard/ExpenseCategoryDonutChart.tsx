
"use client";

import type { FC } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { ChartContainer, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { formatCurrency, parseNumber } from '@/data/dashboard-data'; // Import parseNumber
import { CardDescription } from '../ui/card';
import type { Measure } from '@/types'; 

interface ExpenseCategoryDonutChartProps {
  measures: Measure[] | null;
}

// Helper function to generate a list of distinct chart colors
const generateChartColors = (numColors: number): string[] => {
  const baseColors = [
    "hsl(var(--chart-1))", 
    "hsl(var(--chart-2))", 
    "hsl(var(--chart-3))", 
    "hsl(var(--chart-4))", 
    "hsl(var(--chart-5))"
    // Add more theme colors if needed, e.g., "hsl(var(--chart-6))", etc.
  ];
  const colors = [];
  for (let i = 0; i < numColors; i++) {
    colors.push(baseColors[i % baseColors.length]);
  }
  return colors;
};

const ExpenseCategoryDonutChart: FC<ExpenseCategoryDonutChartProps> = ({ measures }) => {
  if (!Array.isArray(measures) || measures.length === 0) {
    return <div className="flex items-center justify-center h-full min-h-[300px] text-muted-foreground p-4">Keine Daten für dieses Diagramm verfügbar. Prüfen Sie die 'massnahmen'-Datenquelle.</div>;
  }

  const savingsByDepartment = measures.reduce((acc, measure) => {
    const department = measure.Department || 'Unbekannt';
    // Use parseNumber for robust conversion
    const realizedSavingsValue = parseNumber(measure.Realisierte_Einsparung);
    acc[department] = (acc[department] || 0) + realizedSavingsValue;
    return acc;
  }, {} as Record<string, number>);

  const departmentList = Object.keys(savingsByDepartment).filter(dept => savingsByDepartment[dept] > 0);
  
  if (departmentList.length === 0) {
    return <div className="flex items-center justify-center h-full min-h-[300px] text-muted-foreground p-4">Für dieses Diagramm konnten keine relevanten Datenpunkte aus den Maßnahmen generiert werden (z.B. alle realisierten Einsparungen sind 0 oder Abteilungen fehlen).</div>;
  }
  
  const departmentColors = generateChartColors(departmentList.length);

  const chartData = departmentList.map((name, index) => ({
    name,
    value: savingsByDepartment[name],
    fill: departmentColors[index], // Assign distinct color
  }));
  
  const totalSavings = chartData.reduce((acc, curr) => acc + curr.value, 0);

  // Dynamically generate chartConfig based on departments and their colors
  const chartConfig = chartData.reduce((config, item) => {
    config[item.name] = { label: item.name, color: item.fill };
    return config;
  }, {} as ChartConfig);

  // Add a default for 'value' if not already present (for tooltip formatting)
  if (!chartConfig.value) {
    chartConfig.value = { label: "Betrag" };
  }

  return (
    <ChartContainer config={chartConfig} className="h-full w-full">
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Tooltip
            content={<ChartTooltipContent 
              formatter={(value, name, props) => {
                // props.payload refers to the specific segment's data in chartData
                const categoryConfig = chartConfig[name as string] || {};
                return (
                  <>
                    <div className="font-medium text-foreground">{categoryConfig.label || name}</div>
                    <div className="text-muted-foreground">
                      {formatCurrency(value as number)} ({totalSavings > 0 ? ((value as number / totalSavings) * 100).toFixed(1) : 0}%)
                    </div>
                  </>
                )
              }}
              indicator="dot" 
              hideLabel 
            />}
            cursor={{ fill: "hsl(var(--muted) / 0.3)" }}
          />
          <Pie
            data={chartData}
            dataKey="value"
            nameKey="name"
            cx="50%"
            cy="50%"
            innerRadius="55%" 
            outerRadius="80%"
            paddingAngle={2}
            labelLine={false}
            // label={({ cx, cy, midAngle, innerRadius, outerRadius, percent, index, name }) => {
            //   const RADIAN = Math.PI / 180;
            //   const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
            //   const x = cx + radius * Math.cos(-midAngle * RADIAN);
            //   const y = cy + radius * Math.sin(-midAngle * RADIAN);
            //   return (percent * 100) > 5 ? ( // Only show label if percentage is > 5%
            //     <text x={x} y={y} fill="hsl(var(--card-foreground))" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central" fontSize="10px">
            //       {`${(percent * 100).toFixed(0)}%`}
            //     </text>
            //   ) : null;
            // }}
          >
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.fill} stroke={entry.fill} />
            ))}
          </Pie>
          <Legend 
            verticalAlign="bottom" 
            height={50} 
            iconSize={10}
            wrapperStyle={{fontSize: "12px", paddingTop: "20px"}}
            layout="horizontal"
            align="center"
            formatter={(value, entry) => { 
                 // entry.payload refers to the original data object for this legend item
                 const itemConfig = chartData.find(item => item.name === value);
                 // Use the color from the chartData/chartConfig
                 const color = itemConfig ? itemConfig.fill : 'hsl(var(--muted-foreground))';
                 return <span style={{ color: color }}>{itemConfig?.name || value}</span>;
            }}
          />
        </PieChart>
      </ResponsiveContainer>
      {totalSavings > 0 && (
        <CardDescription className="text-center text-sm text-muted-foreground mt-2">
          Gesamte realisierte Einsparungen: {formatCurrency(totalSavings)}
        </CardDescription>
      )}
    </ChartContainer>
  );
};

export default ExpenseCategoryDonutChart;
