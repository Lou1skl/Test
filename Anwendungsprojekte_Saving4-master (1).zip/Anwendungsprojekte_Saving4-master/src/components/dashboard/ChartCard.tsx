import type { FC, ReactNode } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface ChartCardProps {
  title: string;
  icon: ReactNode;
  children: ReactNode;
  className?: string;
}

const ChartCard: FC<ChartCardProps> = ({ title, icon, children, className }) => {
  return (
    <Card className={`shadow-medium rounded-lg ${className}`}>
      <CardHeader>
        <CardTitle className="flex items-center text-xl font-semibold text-foreground">
          <span className="mr-3 text-primary">{icon}</span>
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="min-h-[300px] md:min-h-[350px]">
          {children}
        </div>
      </CardContent>
    </Card>
  );
};

export default ChartCard;
