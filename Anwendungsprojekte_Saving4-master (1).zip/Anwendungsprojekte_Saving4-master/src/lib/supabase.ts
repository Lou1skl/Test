
import { createServerComponentClient, createClientComponentClient } from '@supabase/auth-helpers-nextjs';
import type { SupabaseClient } from '@supabase/supabase-js';
import type { CookiesFn } from '@supabase/auth-helpers-nextjs';
import type { ReadonlyRequestCookies } from 'next/dist/server/web/spec-extension/adapters/request-cookies';
import type { Measure } from '@/types';

// Note: The actual Supabase URL and Anon Key should be in .env.local
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Supabase URL or Anon Key is missing. Please check environment variables (NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY).');
}

// For Server Components, Route Handlers
export const createSupabaseServerClient = (cookies: CookiesFn | ReadonlyRequestCookies) => {
  if (!supabaseUrl || !supabaseAnonKey) {
    throw new Error('Supabase URL or Anon Key is not configured.');
  }
  return createServerComponentClient({ cookies: () => cookies }, {
    supabaseUrl,
    supabaseKey: supabaseAnonKey,
  });
};

// For Client Components
export const createSupabaseClientComponent = () => {
  if (!supabaseUrl || !supabaseAnonKey) {
    throw new Error('Supabase URL or Anon Key is not configured.');
  }
  return createClientComponentClient({
    supabaseUrl,
    supabaseKey: supabaseAnonKey,
  });
};


export async function getMeasures(supabase: SupabaseClient): Promise<Measure[]> {
  console.log("Attempting to fetch measures from 'massnahmen' table...");
  const { data, error } = await supabase
    .from('massnahmen')
    .select(
      `
        Massnahmen_ID,
        Massnahmen_beschreibung,
        Kostenstelle,
        Geplante_Einsparung,
        Realisierte_Einsparung,
        Status,
        Letztes_Update,
        Erfuellungsgrad,
        TimetoSaving,
        ROISchaetzung,
        AutomatisierteKPIStatus,
        Department
      `
    );

  if (error) {
    console.error('Error fetching measures:', error);
    return [];
  }

  if (!data || data.length === 0) {
    console.warn("Supabase connection successful, but no data returned from 'massnahmen' table. This could be due to an empty table or RLS policies restricting access.");
    return [];
  }

  console.log(`Successfully fetched ${data.length} measures.`);
  return (data as Measure[]) || [];
}

export async function getUniqueDepartments(supabase: SupabaseClient): Promise<string[]> {
  const { data, error } = await supabase
    .from('massnahmen')
    .select('Department');

  if (error) {
    console.error('Error fetching unique departments:', error);
    return [];
  }
  if (!data) {
    return [];
  }

  const departments = data.map(item => item.Department).filter(Boolean);
  return Array.from(new Set(departments as string[]));
}

export async function getMeasuresByDepartment(supabase: SupabaseClient, departmentName: string): Promise<Measure[]> {
  const { data, error } = await supabase
    .from('massnahmen')
    .select(
      `
        Massnahmen_ID,
        Massnahmen_beschreibung,
        Kostenstelle,
        Geplante_Einsparung,
        Realisierte_Einsparung,
        Status,
        Letztes_Update,
        Erfuellungsgrad,
        TimetoSaving,
        ROISchaetzung,
        AutomatisierteKPIStatus,
        Department
      `
    )
    .eq('Department', departmentName);

  if (error) {
    console.error(`Error fetching measures for department ${departmentName}:`, error);
    return [];
  }
  return (data as Measure[]) || [];
}

export async function getMeasureById(supabase: SupabaseClient, id: string): Promise<Measure | null> {
  const { data, error } = await supabase
    .from('massnahmen')
    .select(
      `
        Massnahmen_ID,
        Massnahmen_beschreibung,
        Kostenstelle,
        Geplante_Einsparung,
        Realisierte_Einsparung,
        Status,
        Letztes_Update,
        Erfuellungsgrad,
        TimetoSaving,
        ROISchaetzung,
        AutomatisierteKPIStatus,
        Department
      `
    )
    .eq('Massnahmen_ID', id)
    .single();

  if (error) {
    console.error(`Error fetching measure with ID ${id}:`, error);
    return null;
  }
  return data as Measure | null;
}
