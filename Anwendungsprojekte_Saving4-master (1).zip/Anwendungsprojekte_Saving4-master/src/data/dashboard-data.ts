
import type { ChartConfig } from "@/components/ui/chart";
import type { LucideIcon } from "lucide-react";
import { Wallet, ShoppingCart, TrendingUp, Target, Percent, ArrowDown, Activity } from 'lucide-react';

export type KpiData = {
  title: string;
  value: string;
  subtext?: string;
  icon: LucideIcon;
  bgColorClass: string; // For vibrant backgrounds
};

// Updated KPI data for finance dashboard
export const kpiDataItems: KpiData[] = [
  { title: "Gesamteinnahmen", value: "1.250.000 €", icon: Wallet, bgColorClass: "kpi-bg-blue", subtext: "+5.2% zum Vormonat" },
  { title: "Gesamtausgaben", value: "780.000 €", icon: ShoppingCart, bgColorClass: "kpi-bg-red-pink", subtext: "+3.1% zum Vormonat" },
  { title: "Nettogewinn", value: "470.000 €", icon: Activity, bgColorClass: "kpi-bg-green", subtext: "Ziel: 450.000 €" },
  { title: "ROI Marketing", value: "215%", icon: Target, bgColorClass: "kpi-bg-purple", subtext: "Letzte Kampagne" },
];

// Data for "Einnahmen vs. Ausgaben nach Abteilung"
export const revenueExpenseByDepartmentData = [
  { department: "IT", einnahmen: 180000, ausgaben: 75000 },
  { department: "HR", einnahmen: 90000, ausgaben: 45000 },
  { department: "Finance", einnahmen: 320000, ausgaben: 110000 },
  { department: "Marketing", einnahmen: 270000, ausgaben: 160000 },
  { department: "Sales", einnahmen: 390000, ausgaben: 185000 },
  { department: "Operations", einnahmen: 150000, ausgaben: 90000 },
];

export const revenueExpenseByDepartmentChartConfig = {
  einnahmen: {
    label: "Einnahmen",
    color: "hsl(var(--chart-1))", // Blue
  },
  ausgaben: {
    label: "Ausgaben",
    color: "hsl(var(--chart-2))", // Red/Pink
  },
} satisfies ChartConfig;

// Data for "Finanzentwicklung über Zeit" (Einnahmen, Ausgaben, Nettogewinn)
export const financialTrendData = [
  { date: "Jan '24", einnahmen: 180000, ausgaben: 100000, netto: 80000, fullDate: "Januar 2024" },
  { date: "Feb '24", einnahmen: 200000, ausgaben: 110000, netto: 90000, fullDate: "Februar 2024" },
  { date: "Mrz '24", einnahmen: 220000, ausgaben: 120000, netto: 100000, fullDate: "März 2024" },
  { date: "Apr '24", einnahmen: 210000, ausgaben: 130000, netto: 80000, fullDate: "April 2024" },
  { date: "Mai '24", einnahmen: 240000, ausgaben: 140000, netto: 100000, fullDate: "Mai 2024" },
  { date: "Jun '24", einnahmen: 250000, ausgaben: 150000, netto: 100000, fullDate: "Juni 2024" },
];

export const financialTrendChartConfig = {
  einnahmen: {
    label: "Einnahmen",
    color: "hsl(var(--chart-1))", // Blue
  },
  ausgaben: {
    label: "Ausgaben",
    color: "hsl(var(--chart-2))", // Red/Pink
  },
  netto: {
    label: "Nettogewinn",
    color: "hsl(var(--chart-3))", // Green
  },
} satisfies ChartConfig;

// Data for "Ausgabenkategorien" Donut Chart
export const expenseCategoriesData = [
  { name: "Personal", value: 350000, fill: "hsl(var(--chart-1))" },
  { name: "Marketing", value: 150000, fill: "hsl(var(--chart-2))" },
  { name: "Betriebskosten", value: 120000, fill: "hsl(var(--chart-3))" },
  { name: "Miete & Infrastruktur", value: 90000, fill: "hsl(var(--chart-4))" },
  { name: "Sonstiges", value: 70000, fill: "hsl(var(--chart-5))" },
];

export const expenseCategoriesChartConfig = {
  value: {
    label: "Betrag",
  },
  Personal: { label: "Personal", color: "hsl(var(--chart-1))" },
  Marketing: { label: "Marketing", color: "hsl(var(--chart-2))" },
  Betriebskosten: { label: "Betriebskosten", color: "hsl(var(--chart-3))" },
  "Miete & Infrastruktur": { label: "Miete & Infrastruktur", color: "hsl(var(--chart-4))" },
  Sonstiges: { label: "Sonstiges", color: "hsl(var(--chart-5))" },
} satisfies ChartConfig;


// Type for "Wichtige Finanzposten" table
export type TransactionStatus = "Abgeschlossen" | "Ausstehend" | "Überfällig" | "Geplant";
export type Transaction = {
  id: string;
  beschreibung: string;
  kategorie: string;
  datum: string;
  betrag: string;
  status: TransactionStatus;
  empfaengerZahler: string; // Empfänger/Zahler
};

// Data for "Wichtige Finanzposten" table
export const financialTransactionsData: Transaction[] = [
  { id: "1", beschreibung: "Gehaltszahlungen März", kategorie: "Personal", datum: "28.03.2024", betrag: "-120.500 €", status: "Abgeschlossen", empfaengerZahler: "Mitarbeiter" },
  { id: "2", beschreibung: "Softwarelizenz Adobe CC", kategorie: "Betriebskosten", datum: "15.03.2024", betrag: "-1.200 €", status: "Abgeschlossen", empfaengerZahler: "Adobe Inc." },
  { id: "3", beschreibung: "Eingang Kunde Alpha Projekt", kategorie: "Einnahmen", datum: "10.04.2024", betrag: "+25.000 €", status: "Ausstehend", empfaengerZahler: "Alpha GmbH" },
  { id: "4", beschreibung: "Marketingkampagne Q2", kategorie: "Marketing", datum: "01.04.2024", betrag: "-15.000 €", status: "Geplant", empfaengerZahler: "Social Media Inc." },
  { id: "5", beschreibung: "Miete Büro Q2", kategorie: "Miete & Infrastruktur", datum: "05.04.2024", betrag: "-8.000 €", status: "Überfällig", empfaengerZahler: "Immobilien AG" },
  { id: "6", beschreibung: "Reisekosten Vertrieb", kategorie: "Sonstiges", datum: "20.03.2024", betrag: "-2.300 €", status: "Abgeschlossen", empfaengerZahler: "Diverse Hotels/Airlines" },
  { id: "7", beschreibung: "Investition neue Server", kategorie: "Betriebskosten", datum: "12.04.2024", betrag: "-22.000 €", status: "Geplant", empfaengerZahler: "Hardware Corp." },
];

export const formatCurrency = (value: number, currency = 'EUR') => {
  return new Intl.NumberFormat('de-DE', { style: 'currency', currency: currency }).format(value);
};

// Helper function to parse numbers, handling potential string inputs
export const parseNumber = (value: number | string | undefined | null): number => {
  if (typeof value === 'number') {
    return value;
  }
  if (typeof value === 'string') {
    // Remove currency symbols, thousands separators (like periods for de-DE), 
    // and replace comma decimal with dot for parseFloat.
    const cleanedValue = value.replace(/[^0-9,.-]+/g, '').replace(/\./g, '').replace(',', '.');
    return parseFloat(cleanedValue) || 0;
  }
  return 0;
};
