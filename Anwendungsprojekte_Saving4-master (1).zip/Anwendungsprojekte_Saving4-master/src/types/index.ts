
// src/types/index.ts
export interface Measure {
  Massnahmen_ID: string;
  Massnahmen_beschreibung?: string; // Added as optional, as it's used in projekt details
  Kostenstelle: number;
  Geplante_Einsparung: number;
  Realisierte_Einsparung: number;
  Status: string;
  Letztes_Update: string; 
  Erfuellungsgrad: number;
  TimetoSaving: number;
  ROISchaetzung: number;
  AutomatisierteKPIStatus: string;
  Department: string;
}
