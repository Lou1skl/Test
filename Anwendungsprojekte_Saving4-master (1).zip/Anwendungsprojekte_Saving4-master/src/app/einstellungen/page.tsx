// src/app/einstellungen/page.tsx
import PageHeader from '@/components/dashboard/PageHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';

export default function EinstellungenPage() {
  return (
    <main className="min-h-screen bg-background text-foreground p-4 md:p-6 lg:p-8">
      <PageHeader title="Einstellungen" />

      <div className="space-y-6 md:space-y-8 max-w-2xl mx-auto">
        <Card className="shadow-medium rounded-lg">
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-foreground">Allgemeine Einstellungen</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="username">Benutzername</Label>
              <Input id="username" defaultValue="Max Mustermann" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">E-Mail-Adresse</Label>
              <Input id="email" type="email" defaultValue="max.mustermann@example.com" />
            </div>
            <div className="flex items-center space-x-2 pt-2">
              <Switch id="dark-mode" />
              <Label htmlFor="dark-mode">Dunkelmodus aktivieren</Label>
            </div>
             <div className="flex items-center space-x-2">
              <Switch id="email-notifications" defaultChecked />
              <Label htmlFor="email-notifications">E-Mail Benachrichtigungen</Label>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-medium rounded-lg">
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-foreground">Sicherheit</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
                <Button variant="outline">Passwort ändern</Button>
            </div>
            <div>
                <Button variant="outline">Zwei-Faktor-Authentifizierung einrichten</Button>
            </div>
          </CardContent>
        </Card>
        
        <div className="flex justify-end pt-4">
            <Button>Änderungen speichern</Button>
        </div>
      </div>
    </main>
  );
}
