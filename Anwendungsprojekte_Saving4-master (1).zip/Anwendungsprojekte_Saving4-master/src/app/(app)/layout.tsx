
'use client'; 

import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarInset,
} from '@/components/ui/sidebar';
import ClientSidebarMenu from '@/components/layout/ClientSidebarMenu';
import { Button } from '@/components/ui/button';
import { Settings, LayoutDashboard, LogOut as LogOutIcon } from 'lucide-react'; 
import Link from 'next/link';
import { useEffect, useState } from 'react'; 
import { useRouter } from 'next/navigation';
import { createSupabaseClientComponent } from '@/lib/supabase'; 
import type { SupabaseClient } from '@supabase/supabase-js';
import { getUniqueDepartments as fetchUniqueDepartments } from '@/lib/supabase'; 
import { useToast } from "@/hooks/use-toast"; // Added import for toast

export default function AppLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const router = useRouter();
  const { toast } = useToast(); // Initialize toast
  const [supabase, setSupabase] = useState<SupabaseClient | null>(null);
  const [departments, setDepartments] = useState<string[]>([]);

  useEffect(() => {
    const client = createSupabaseClientComponent();
    setSupabase(client);

    async function loadDepartments() {
      if (client) { 
        const fetchedDepartments = await fetchUniqueDepartments(client);
        setDepartments(fetchedDepartments);
      }
    }
    loadDepartments();
  }, []); 

  const handleLogout = async () => {
    if (supabase) {
      toast({
        title: "Ausloggen...",
        description: "Bitte warten Sie einen Moment.",
      });
      const { error } = await supabase.auth.signOut();
      if (error) {
        console.error('Error logging out:', error);
        toast({
          title: "Logout fehlgeschlagen",
          description: error.message || "Beim Ausloggen ist ein Fehler aufgetreten.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Erfolgreich ausgeloggt",
          description: "Sie werden zur Startseite weitergeleitet.",
        });
        // Full page navigation to ensure all state is cleared
        // and middleware re-evaluates correctly with no session.
        window.location.assign('/'); 
      }
    } else {
       toast({
        title: "Logout nicht möglich",
        description: "Keine aktive Verbindung zum Server.",
        variant: "destructive",
      });
      console.warn('Supabase client not available for logout.');
    }
  };

  return (
    <SidebarProvider defaultOpen={false}>
      <Sidebar collapsible="icon">
        <SidebarHeader className="p-2 flex justify-center items-center group-data-[collapsible=icon]:py-2">
          <Button variant="ghost" size="icon" className="w-auto h-auto p-1 mx-auto" asChild>
            <Link href="/dashboard" aria-label="Dashboard">
              <LayoutDashboard className="h-6 w-6 text-primary" />
            </Link>
          </Button>
        </SidebarHeader>
        <SidebarContent>
          {supabase && <ClientSidebarMenu departments={departments} supabase={supabase} />}
        </SidebarContent>
        <SidebarFooter className="p-2 mt-auto space-y-1">
           <Button variant="ghost" className="w-full justify-start group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:aspect-square" asChild>
              <Link href="/einstellungen">
                <Settings className="mr-2 group-data-[collapsible=icon]:mr-0" />
                <span className="group-data-[collapsible=icon]:hidden">Einstellungen</span>
              </Link>
          </Button>
          <Button variant="ghost" className="w-full justify-start group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:aspect-square" onClick={handleLogout}>
            <LogOutIcon className="mr-2 group-data-[collapsible=icon]:mr-0" />
            <span className="group-data-[collapsible=icon]:hidden">Logout</span>
          </Button>
        </SidebarFooter>
      </Sidebar>
      <SidebarInset>
        {children}
      </SidebarInset>
    </SidebarProvider>
  );
}
