
import PageHeader from '@/components/dashboard/PageHeader';
import KpiSection from '@/components/dashboard/KpiSection';
import ChartsSection from '@/components/dashboard/ChartsSection';
import FinancialTransactionsTable from '@/components/dashboard/FinancialTransactionsTable';
import { getMeasures } from '@/lib/supabase';
import { createSupabaseServerClient } from '@/lib/supabase'; // Updated import
import type { Measure } from '@/types';
import { cookies } from 'next/headers';

export default async function DashboardPage() {
  const cookieStore = cookies();
  const supabase = createSupabaseServerClient(cookieStore); // Use the new helper
  const measures: Measure[] = await getMeasures(supabase);

  return (
    <main className="min-h-screen bg-background text-foreground p-4 md:p-6 lg:p-8">
      <PageHeader title="Finanzübersicht Management" showExportButton={true} />
      <div className="space-y-6 md:space-y-8">
        <KpiSection measures={measures} />
        <ChartsSection measures={measures} />
        <FinancialTransactionsTable data={measures} /> 
      </div>
    </main>
  );
}
