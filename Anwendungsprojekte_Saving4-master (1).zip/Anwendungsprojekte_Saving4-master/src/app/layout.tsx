
import type { Metadata } from 'next';
import { GeistSans } from 'geist/font/sans';
import './globals.css';
import { Toaster } from "@/components/ui/toaster";

const geistSans = GeistSans;

export const metadata: Metadata = {
  title: 'CostWise Dashboard', // Default title, can be overridden by pages
  description: 'Strategische Kostentransparenz und Maßnahmenverfolgung für Ihr Unternehmen.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="de" className={`${geistSans.variable} font-sans antialiased`}>
      <head>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"/>
      </head>
      <body>
        {children}
        <Toaster />
      </body>
    </html>
  );
}
