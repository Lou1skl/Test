
import PageHeader from '@/components/dashboard/PageHeader';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, CalendarDays, Target, DollarSign, Percent as PercentIcon, Info, ListChecks } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getMeasureById, getUniqueDepartments } from '@/lib/supabase'; 
import { createSupabaseServerClient } from '@/lib/supabase'; // Updated import
import type { Measure } from '@/types';
import { formatCurrency, parseNumber } from '@/data/dashboard-data';
import { Progress } from '@/components/ui/progress'; 
import { cn } from '@/lib/utils'; 
import { cookies } from 'next/headers';

interface ProjektPageProps {
  params: {
    bereichId: string; 
    projektId: string; 
  };
}

const formatName = (id: string) => id.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');

export default async function ProjektPage({ params }: ProjektPageProps) {
  const { bereichId, projektId } = params;
  const cookieStore = cookies();
  const supabase = createSupabaseServerClient(cookieStore); // Use the new helper
  
  const measure: Measure | null = await getMeasureById(supabase, projektId);

  if (!measure) {
    return (
      <main className="min-h-screen bg-background text-foreground p-4 md:p-6 lg:p-8">
        <PageHeader title="Projektdetails" />
        <p className="text-muted-foreground">Das angeforderte Projekt (Maßnahme) konnte nicht gefunden werden.</p>
      </main>
    );
  }
  
  const allDepartments = await getUniqueDepartments(supabase);
  const originalDeptName = allDepartments.find(d => d.toLowerCase().replace(/\s+/g, '-') === bereichId) || measure.Department;
  const bereichNameFormatted = originalDeptName ? (originalDeptName.charAt(0).toUpperCase() + originalDeptName.slice(1)) : formatName(bereichId);
  const projektNameFormatted = measure.Massnahmen_beschreibung || `Maßnahme ${projektId}`;


  const getStatusBadgeClass = (status?: string) => {
    const lowerStatus = status?.toLowerCase();
    if (!lowerStatus) return "bg-secondary text-secondary-foreground";
    if (lowerStatus.includes('abgeschlossen') || lowerStatus === 'erfuellt') return "badge-success";
    if (lowerStatus.includes('risiko')) return "badge-destructive";
    if (lowerStatus.includes('ueber plan') || lowerStatus.includes('über plan')) return "bg-blue-500 text-white"; 
    if (lowerStatus.includes('im rahmen')) return "badge-neutral";
    if (lowerStatus.includes('geplant')) return "badge-neutral";
    if (lowerStatus.includes('in bearbeitung')) return "badge-warning";
    return "bg-secondary text-secondary-foreground";
  };
  
  const erfuellungsgradNum = parseNumber(measure.Erfuellungsgrad);

  return (
    <main className="min-h-screen bg-background text-foreground p-4 md:p-6 lg:p-8">
      <PageHeader title={`Maßnahmedetails: ${projektNameFormatted}`} showExportButton={false} />
      
      <div className="space-y-6 md:space-y-8">
        <Card className="shadow-medium rounded-lg">
          <CardHeader>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
              <CardTitle className="text-xl font-semibold text-foreground">
                {projektNameFormatted}
              </CardTitle>
              <Badge variant="secondary">Bereich: {bereichNameFormatted}</Badge>
            </div>
             {measure.Massnahmen_ID && (
                <CardDescription className="text-sm text-muted-foreground pt-1">
                    ID: {measure.Massnahmen_ID}
                </CardDescription>
            )}
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <ListChecks size={20} className="mr-2 text-primary" /> Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Badge className={cn("text-base", getStatusBadgeClass(measure.Status))}>
                    {measure.Status || 'N/A'}
                  </Badge>
                  {measure.AutomatisierteKPIStatus && (
                    <div className="text-sm text-muted-foreground mt-2 flex items-center gap-x-2">
                      <span>KPI Status:</span>
                      <Badge variant="outline" className={cn(getStatusBadgeClass(measure.AutomatisierteKPIStatus))}>{measure.AutomatisierteKPIStatus}</Badge>
                    </div>
                  )}
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <DollarSign size={20} className="mr-2 text-primary" /> Einsparungen
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-lg font-semibold">{formatCurrency(parseNumber(measure.Realisierte_Einsparung))}</p>
                  <p className="text-sm text-muted-foreground">
                    Geplant: {formatCurrency(parseNumber(measure.Geplante_Einsparung))}
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <PercentIcon size={20} className="mr-2 text-primary" /> Erfüllungsgrad
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{erfuellungsgradNum.toFixed(1)} %</p>
                  <Progress value={erfuellungsgradNum} className="mt-2 h-3" />
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <CalendarDays size={20} className="mr-2 text-primary" /> Zeitplan
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-md">Letztes Update: {measure.Letztes_Update ? new Date(measure.Letztes_Update).toLocaleDateString('de-DE') : 'N/A'}</p>
                  <p className="text-sm text-muted-foreground">Time-to-Saving: {measure.TimetoSaving || 'N/A'} Tage</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <Target size={20} className="mr-2 text-primary" /> ROI
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{parseNumber(measure.ROISchaetzung).toFixed(1)} %</p>
                  <p className="text-sm text-muted-foreground">Geschätzter Return on Investment</p>
                </CardContent>
              </Card>
               <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center">
                    <Info size={20} className="mr-2 text-primary" /> Details
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-md">Kostenstelle: {measure.Kostenstelle || 'N/A'}</p>
                </CardContent>
              </Card>
            </div>

            <div className="mt-8">
              <h3 className="text-lg font-semibold mb-3">Zugehörige Dokumente (Platzhalter)</h3>
              <ul className="space-y-2">
                <li>
                  <Button variant="link" className="p-0 h-auto" asChild>
                    <a href="#" target="_blank" rel="noopener noreferrer">
                      Detailanalyse der Maßnahme <ExternalLink size={16} className="ml-1" />
                    </a>
                  </Button>
                </li>
                <li>
                   <Button variant="link" className="p-0 h-auto" asChild>
                    <a href="#" target="_blank" rel="noopener noreferrer">
                      Risikobewertung <ExternalLink size={16} className="ml-1" />
                    </a>
                  </Button>
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
