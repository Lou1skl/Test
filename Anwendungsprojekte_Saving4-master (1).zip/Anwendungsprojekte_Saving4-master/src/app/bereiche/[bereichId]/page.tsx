
import Link from 'next/link';
import PageHeader from '@/components/dashboard/PageHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, ChevronRight, Briefcase, Target, DollarSign, Layers, Package, TrendingUp as TrendingUpIcon, Percent } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { getMeasuresByDepartment, getUniqueDepartments } from '@/lib/supabase';
import { createSupabaseServerClient } from '@/lib/supabase'; // Updated import
import type { Measure } from '@/types';
import { parseNumber, formatCurrency } from '@/data/dashboard-data';
import { cookies } from 'next/headers';

interface BereichPageProps {
  params: {
    bereichId: string; 
  };
}

const formatCurrencyKPI = (value: number): string => {
  return new Intl.NumberFormat('de-DE', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

export default async function BereichPage({ params }: BereichPageProps) {
  const { bereichId } = params;
  const cookieStore = cookies();
  const supabase = createSupabaseServerClient(cookieStore); // Use the new helper

  const allDepartments = await getUniqueDepartments(supabase);
  const originalDeptName = allDepartments.find(d => d.toLowerCase().replace(/\s+/g, '-') === bereichId);

  if (!originalDeptName) {
    return (
      <main className="min-h-screen bg-background text-foreground p-4 md:p-6 lg:p-8">
        <PageHeader title="Bereich nicht gefunden" />
        <p>Der angeforderte Bereich konnte nicht gefunden werden.</p>
      </main>
    );
  }
  
  const departmentMeasures: Measure[] = await getMeasuresByDepartment(supabase, originalDeptName);

  const bereichNameFormatted = originalDeptName.charAt(0).toUpperCase() + originalDeptName.slice(1);

  const totalPlannedSavings = departmentMeasures.reduce((sum, m) => sum + parseNumber(m.Geplante_Einsparung), 0);
  const totalRealizedSavings = departmentMeasures.reduce((sum, m) => sum + parseNumber(m.Realisierte_Einsparung), 0);
  const totalMeasuresInDept = departmentMeasures.length;
  
  const numericErfuellungsgrade = departmentMeasures
    .map(m => m.Erfuellungsgrad)
    .filter(ef => typeof ef === 'number') as number[];
  const totalFulfillmentSum = numericErfuellungsgrade.reduce((sum, ef) => sum + ef, 0);
  const averageFulfillmentRate = numericErfuellungsgrade.length > 0 
    ? totalFulfillmentSum / numericErfuellungsgrade.length 
    : 0;
  
  const aktiveProjekteCount = departmentMeasures.filter(p => p.Status?.toLowerCase() === 'aktiv' || p.Status?.toLowerCase() === 'in bearbeitung').length;


  return (
    <main className="min-h-screen bg-background text-foreground p-4 md:p-6 lg:p-8">
      <PageHeader title={`Bereichsübersicht: ${bereichNameFormatted}`} showExportButton={true} />
      
      <div className="space-y-6 md:space-y-8">
        
        <Card className="shadow-medium rounded-lg">
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-foreground flex items-center">
              <Briefcase size={24} className="mr-3 text-primary" />
              Kennzahlen für {bereichNameFormatted}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className={cn("kpi-bg-blue", "shadow-medium rounded-lg text-card-foreground overflow-hidden transform transition-all hover:scale-105 hover:shadow-lg")}>
                <CardContent className="p-6 flex flex-col justify-between h-full">
                    <div className="flex justify-between items-start mb-2">
                        <div className="flex-grow">
                            <h3 className="text-sm font-medium opacity-80 uppercase tracking-wider">Maßnahmen Gesamt</h3>
                            <div className="text-3xl font-bold mt-1">{totalMeasuresInDept}</div>
                        </div>
                        <Package size={36} className="opacity-70" />
                    </div>
                </CardContent>
              </Card>
              <Card className={cn("kpi-bg-red-pink", "shadow-medium rounded-lg text-card-foreground overflow-hidden transform transition-all hover:scale-105 hover:shadow-lg")}>
                <CardContent className="p-6 flex flex-col justify-between h-full">
                     <div className="flex justify-between items-start mb-2">
                        <div className="flex-grow">
                            <h3 className="text-sm font-medium opacity-80 uppercase tracking-wider">Geplante Einsparung</h3>
                            <div className="text-3xl font-bold mt-1">{formatCurrencyKPI(totalPlannedSavings)}</div>
                        </div>
                        <TrendingUpIcon size={36} className="opacity-70" />
                    </div>
                </CardContent>
              </Card>
              <Card className={cn("kpi-bg-green", "shadow-medium rounded-lg text-card-foreground overflow-hidden transform transition-all hover:scale-105 hover:shadow-lg")}>
                <CardContent className="p-6 flex flex-col justify-between h-full">
                    <div className="flex justify-between items-start mb-2">
                        <div className="flex-grow">
                            <h3 className="text-sm font-medium opacity-80 uppercase tracking-wider">Realisierte Einsparung</h3>
                            <div className="text-3xl font-bold mt-1">{formatCurrencyKPI(totalRealizedSavings)}</div>
                        </div>
                        <DollarSign size={36} className="opacity-70" />
                    </div>
                </CardContent>
              </Card>
               <Card className={cn("kpi-bg-purple", "shadow-medium rounded-lg text-card-foreground overflow-hidden transform transition-all hover:scale-105 hover:shadow-lg")}>
                <CardContent className="p-6 flex flex-col justify-between h-full">
                    <div className="flex justify-between items-start mb-2">
                        <div className="flex-grow">
                            <h3 className="text-sm font-medium opacity-80 uppercase tracking-wider">Ø Erfüllungsgrad</h3>
                            <div className="text-3xl font-bold mt-1">{averageFulfillmentRate.toFixed(1)} %</div>
                        </div>
                        <Percent size={36} className="opacity-70" />
                    </div>
                </CardContent>
              </Card>
            </div>
             {aktiveProjekteCount > 0 && (
              <div className="text-center mt-6 text-muted-foreground">
                Davon <Badge variant="secondary">{aktiveProjekteCount}</Badge> {aktiveProjekteCount === 1 ? "aktives Projekt" : "aktive Projekte"}.
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-medium rounded-lg">
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-foreground">Maßnahmen im Bereich {bereichNameFormatted}</CardTitle>
          </CardHeader>
          <CardContent>
            {departmentMeasures.length > 0 ? (
              <ul className="space-y-3">
                {departmentMeasures.map((measure) => (
                  <li key={measure.Massnahmen_ID}>
                    <Button variant="outline" className="w-full justify-start text-left h-auto py-3 px-4" asChild>
                      <Link href={`/bereiche/${bereichId}/projekte/${measure.Massnahmen_ID}`} className="flex items-center justify-between w-full">
                        <div className="flex items-center">
                          <FileText size={20} className="mr-3 text-primary" />
                          <span className="font-medium mr-3">{measure.Massnahmen_beschreibung || 'Unbenannte Maßnahme'}</span>
                          {measure.Status && 
                            <Badge 
                              variant={measure.Status.toLowerCase().includes('abgeschlossen') || measure.Status.toLowerCase() === 'erfuellt' ? 'secondary' : measure.Status.toLowerCase().includes('bearbeitung') ? 'default' : 'outline'} 
                              className="text-xs"
                            >
                              {measure.Status}
                            </Badge>
                          }
                        </div>
                        <ChevronRight size={20} className="text-muted-foreground" />
                      </Link>
                    </Button>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-muted-foreground">Für diesen Bereich sind aktuell keine Maßnahmen hinterlegt.</p>
            )}
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
