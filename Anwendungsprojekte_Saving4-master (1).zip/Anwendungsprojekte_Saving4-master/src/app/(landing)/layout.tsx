
// This is a simple layout for the landing page, without the main app sidebar.
export default function LandingLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>;
}
