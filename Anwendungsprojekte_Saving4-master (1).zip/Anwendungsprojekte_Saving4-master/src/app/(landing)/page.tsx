
import Link from 'next/link';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Saving4 - Finanzübersicht Management',
};

export default function LandingPage() {
  return (
    <div className="bg-slate-50 text-slate-800 font-geist-sans">
      <nav className="bg-white shadow-md sticky top-0 z-50">
        <div className="container mx-auto px-6 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <span className="material-icons text-blue-600 text-3xl mr-2">savings</span>
            <h1 className="text-2xl font-bold text-blue-600">Saving4</h1>
          </div>
          <Link href="/dashboard" legacyBehavior>
            <a className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-md transition-transform duration-200 ease-in-out hover:-translate-y-0.5 shadow-sm hover:shadow-md">
              Dashboard anzeigen
            </a>
          </Link>
        </div>
      </nav>

      <header className="bg-slate-900 text-white py-20 md:py-28">
        <div className="container mx-auto px-6 text-center">
          <div className="mb-6">
            <span className="material-icons text-blue-400 text-6xl md:text-7xl">query_stats</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
            Effiziente Finanzsteuerung für Ihr Management. <br className="hidden md:block" />Mit Saving4.
          </h2>
          <p className="text-lg md:text-xl mb-10 max-w-3xl mx-auto text-slate-300">
            Saving4: Ihre zentrale Plattform für transparente Finanzkennzahlen. Treffen Sie datengestützte Entscheidungen durch klare Einblicke in Einsparungen, Performance und Maßnahmen.
          </p>
          <Link href="#dashboard-preview" legacyBehavior>
            <a className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-8 rounded-md text-lg transition-transform duration-200 ease-in-out hover:-translate-y-0.5 shadow-md hover:shadow-lg">
              Vorschau entdecken
            </a>
          </Link>
        </div>
      </header>

      <section className="py-16 md:py-20 bg-slate-100">
        <div className="container mx-auto px-6">
          <h3 className="text-3xl md:text-4xl font-bold text-center mb-16 text-slate-700">
            Ihre Kernvorteile mit Saving4
          </h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-lg transition-all duration-300 ease-in-out hover:-translate-y-1 hover:shadow-xl">
              <div className="flex items-center justify-center bg-blue-100 rounded-full w-16 h-16 mb-6 mx-auto">
                <span className="material-icons text-blue-600 text-3xl">visibility</span>
              </div>
              <h4 className="text-xl font-semibold mb-3 text-slate-700 text-center">Zentrale KPI-Übersicht</h4>
              <p className="text-slate-600 leading-relaxed text-center">
                Alle Finanzkennzahlen – geplante vs. realisierte Einsparungen, ROI, Erfüllungsgrade – sofort im Blick.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-lg transition-all duration-300 ease-in-out hover:-translate-y-1 hover:shadow-xl">
              <div className="flex items-center justify-center bg-green-100 rounded-full w-16 h-16 mb-6 mx-auto">
                <span className="material-icons text-green-600 text-3xl">trending_up</span>
              </div>
              <h4 className="text-xl font-semibold mb-3 text-slate-700 text-center">Abteilungs-Performance</h4>
              <p className="text-slate-600 leading-relaxed text-center">
                Analysieren Sie Einsparungen und Maßnahmen detailliert pro Abteilung. Identifizieren Sie Stärken und Potenziale.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-lg transition-all duration-300 ease-in-out hover:-translate-y-1 hover:shadow-xl">
              <div className="flex items-center justify-center bg-purple-100 rounded-full w-16 h-16 mb-6 mx-auto">
                <span className="material-icons text-purple-600 text-3xl">task_alt</span>
              </div>
              <h4 className="text-xl font-semibold mb-3 text-slate-700 text-center">Detaillierte Maßnahmen-Analyse</h4>
              <p className="text-slate-600 leading-relaxed text-center">
                Verfolgen Sie Status und Erfolg jeder einzelnen Maßnahme. Fundierte Daten für gezielte Steuerung.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 bg-slate-50" id="dashboard-preview">
        <div className="container mx-auto px-6">
          <h3 className="text-3xl md:text-4xl font-bold text-center mb-6 text-slate-700">
            Einblick: Das Management-Dashboard
          </h3>
          <p className="text-center text-slate-600 mb-12 max-w-2xl mx-auto">
            Erleben Sie, wie Saving4 komplexe Finanzdaten in klare, handlungsorientierte Visualisierungen verwandelt.
          </p>
          <div className="bg-white p-6 sm:p-8 rounded-xl shadow-2xl border border-slate-200">
            <div className="flex flex-col md:flex-row justify-between items-center mb-8 px-1 md:px-2">
              <h1 className="text-2xl md:text-3xl font-bold text-slate-800 mb-4 md:mb-0">Finanzübersicht Management</h1>
              <button className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 px-5 rounded-md flex items-center space-x-2 transition-transform duration-200 ease-in-out hover:-translate-y-0.5 shadow-sm hover:shadow-md">
                <span className="material-icons text-sm">download</span>
                <span>Daten exportieren</span>
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
              <div className="bg-blue-500 text-white p-5 rounded-lg shadow-md">
                <h2 className="text-xs font-medium text-blue-100 uppercase tracking-wider">Gesamte geplante Einsparung</h2>
                <p className="text-3xl font-bold mt-1.5">877.243 €</p>
              </div>
              <div className="bg-green-500 text-white p-5 rounded-lg shadow-md">
                <h2 className="text-xs font-medium text-green-100 uppercase tracking-wider">Gesamte realisierte Einsparung</h2>
                <p className="text-3xl font-bold mt-1.5">692.792 €</p>
              </div>
              <div className="bg-purple-500 text-white p-5 rounded-lg shadow-md">
                <h2 className="text-xs font-medium text-purple-100 uppercase tracking-wider">Durchschnittl. Erfüllungsgrad</h2>
                <p className="text-3xl font-bold mt-1.5">79.9 %</p>
              </div>
              <div className="bg-sky-500 text-white p-5 rounded-lg shadow-md">
                <h2 className="text-xs font-medium text-sky-100 uppercase tracking-wider">Abgeschlossene Maßnahmen</h2>
                <p className="text-3xl font-bold mt-1.5">8 / 50</p>
              </div>
            </div>
            
            <div className="bg-white p-4 sm:p-6 rounded-lg shadow-inner border border-slate-200">
              <div className="flex items-center mb-5">
                <span className="material-icons text-blue-600 text-xl mr-2.5">bar_chart</span>
                <h2 className="text-lg font-semibold text-slate-700">Geplante vs. Realisierte Einsparungen (nach Abt.)</h2>
              </div>
              <div className="flex items-end space-x-4 h-64 relative pl-10">
                <div className="absolute left-0 top-0 bottom-0 flex flex-col justify-between py-1 pr-2 text-xs text-slate-500 h-full -translate-y-2">
                  <span>280k</span>
                  <span>210k</span>
                  <span>140k</span>
                  <span>70k</span>
                  <span className="pb-4">0k</span> 
                </div>
                <div className="absolute bottom-[22px] left-10 right-0 h-px bg-slate-300"></div>
                <div className="absolute top-0 bottom-[22px] left-10 w-px bg-slate-300"></div>

                <div className="flex-1 flex justify-around items-end h-full">
                  {[
                    {real: '60%', plan: '80%', label: 'Abt. 1'},
                    {real: '20%', plan: '45%', label: 'Abt. 2'},
                    {real: '25%', plan: '50%', label: 'Abt. 3'},
                    {real: '40%', plan: '55%', label: 'Abt. 4'},
                  ].map(dept => (
                    <div key={dept.label} className="flex flex-col items-center h-full justify-end" style={{ flexGrow: 1, flexBasis: 0 }}>
                      <div className="flex items-end space-x-1.5 h-full">
                        <div className="bg-blue-500 w-6 md:w-8 rounded-t-sm" style={{ height: dept.real }} title="Realisierte Einsparung"></div>
                        <div className="bg-red-500 w-6 md:w-8 rounded-t-sm" style={{ height: dept.plan }} title="Geplante Einsparung"></div>
                      </div>
                      <span className="text-xs text-slate-600 mt-1.5">{dept.label}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex justify-center space-x-6 mt-6">
                <div className="flex items-center">
                  <span className="w-3.5 h-3.5 bg-blue-500 rounded-sm mr-2"></span>
                  <span className="text-sm text-slate-600">Realisierte Einsparung</span>
                </div>
                <div className="flex items-center">
                  <span className="w-3.5 h-3.5 bg-red-500 rounded-sm mr-2"></span>
                  <span className="text-sm text-slate-600">Geplante Einsparung</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-blue-600 text-white py-16 md:py-20">
        <div className="container mx-auto px-6 text-center">
          <h3 className="text-3xl md:text-4xl font-bold mb-6">
            Bereit für datengestützte Finanzentscheidungen?
          </h3>
          <p className="text-lg md:text-xl mb-10 max-w-2xl mx-auto text-blue-100">
            Entdecken Sie, wie Saving4 Ihr Management-Team mit präzisen Finanzdaten und intuitiven Analysewerkzeugen unterstützt.
          </p>
          <Link href="/dashboard" legacyBehavior>
            <a className="bg-white hover:bg-slate-100 text-blue-600 font-bold py-3 px-8 rounded-md text-lg transition-transform duration-200 ease-in-out hover:-translate-y-0.5 shadow-md hover:shadow-lg">
              Dashboard jetzt erkunden
            </a>
          </Link>
        </div>
      </section>

      <footer className="bg-slate-900 text-slate-300 py-12">
        <div className="container mx-auto px-6 text-center">
          <div className="flex justify-center items-center mb-4">
            <span className="material-icons text-blue-400 text-2xl mr-2">savings</span>
            <p className="text-lg font-semibold text-blue-400">Saving4</p>
          </div>
          <p className="text-sm mb-3">© {new Date().getFullYear()} Saving4. Alle Rechte vorbehalten.</p>
          <div className="space-x-4 text-sm">
            <Link href="#" legacyBehavior><a className="hover:text-blue-400 transition-colors">Datenschutz</a></Link>
            <Link href="#" legacyBehavior><a className="hover:text-blue-400 transition-colors">Impressum</a></Link>
            <Link href="#" legacyBehavior><a className="hover:text-blue-400 transition-colors">Kontakt</a></Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
