
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { createSupabaseClientComponent } from '@/lib/supabase';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { LogIn, Home } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

export default function LoginPage() {
  const router = useRouter();
  const supabase = createSupabaseClientComponent();
  const { toast } = useToast();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const { data, error: signInError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    setLoading(false);

    if (signInError) {
      console.error('Login error:', signInError);
      if (signInError.message.includes('Invalid login credentials')) {
        setError('Ungültige Anmeldedaten. Bitte überprüfen Sie E-Mail und Passwort.');
      } else if (signInError.message.includes('Email not confirmed')) {
        setError('Bitte bestätigen Sie Ihre E-Mail-Adresse, bevor Sie sich anmelden können. Überprüfen Sie Ihr Postfach.');
        toast({
          title: "E-Mail Bestätigung ausstehend",
          description: "Wir haben Ihnen eine Bestätigungs-E-Mail gesendet. Bitte klicken Sie auf den Link darin.",
          variant: "default",
          duration: 9000,
        });
      }
      else {
        setError(signInError.message || 'Ein Fehler ist beim Anmelden aufgetreten.');
      }
    } else if (data.session) {
      toast({
        title: "Anmeldung erfolgreich",
        description: "Sie werden zum Dashboard weitergeleitet.",
      });
      // Introduce a very short delay to potentially help with cookie propagation
      // setTimeout(() => {
      window.location.assign('/dashboard');
      // }, 100); // 100 milliseconds delay
    } else {
      setError('Anmeldung fehlgeschlagen. Keine Session erhalten. Bitte versuchen Sie es erneut.');
      toast({
        title: "Anmeldung fehlgeschlagen",
        description: "Es konnte keine gültige Session gestartet werden.",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="w-full max-w-md shadow-xl">
      <CardHeader className="text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
          <LogIn size={32} />
        </div>
        <CardTitle className="text-2xl font-bold">Anmelden</CardTitle>
        <CardDescription>Bitte melden Sie sich an, um auf das Dashboard zuzugreifen.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleLogin} className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <div className="space-y-2">
            <Label htmlFor="email">E-Mail</Label>
            <Input
              id="email"
              type="email"
              placeholder="max.mustermann@firma.de"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              disabled={loading}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Passwort</Label>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              disabled={loading}
            />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? 'Anmelden...' : 'Anmelden'}
          </Button>
        </form>
        {/* Registration link removed */}
        <p className="mt-4 text-center text-sm text-muted-foreground">
          <Link href="/" className="inline-flex items-center font-medium text-primary hover:underline">
            <Home size={16} className="mr-1" />
            Zurück zur Startseite
          </Link>
        </p>
      </CardContent>
    </Card>
  );
}
