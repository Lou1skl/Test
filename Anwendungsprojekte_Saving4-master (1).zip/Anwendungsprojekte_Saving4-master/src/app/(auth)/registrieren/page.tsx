// This page has been removed as per user request.
// To re-enable registration, you would need to recreate this page
// and link to it from the login page.
export default function RegistrierenPage() {
  return null;
}
