
// src/app/page.tsx
// This file ensures that the root path ("/") renders the main landing page.
// The actual landing page content is defined in /src/app/(landing)/page.tsx.

import LandingPage from './(landing)/page';

export default function RootPage() {
  return <LandingPage />;
}
