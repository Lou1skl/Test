
import { createMiddlewareClient } from '@supabase/auth-helpers-nextjs';
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export async function middleware(req: NextRequest) {
  const res = NextResponse.next();
  const supabase = createMiddlewareClient({ req, res });

  const {
    data: { session },
  } = await supabase.auth.getSession();

  const { pathname } = req.nextUrl;

  // Define protected routes
  const protectedRoutes = ['/dashboard', '/bereiche', '/einstellungen'];
  const isProtectedRoute = protectedRoutes.some(route => pathname.startsWith(route));

  // If no session and trying to access a protected route, redirect to login
  if (!session && isProtectedRoute) {
    const url = req.nextUrl.clone();
    url.pathname = '/login';
    return NextResponse.redirect(url);
  }

  // If session exists and trying to access login page, redirect to dashboard
  if (session && pathname === '/login') {
    const url = req.nextUrl.clone();
    url.pathname = '/dashboard';
    return NextResponse.redirect(url);
  }

  return res;
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - / (the landing page, which should remain public)
     * - /api (API routes, if any, should handle their own auth)
     * - /registrieren (registration page removed)
     */
    '/((?!_next/static|_next/image|favicon.ico|api|registrieren|$).*)',
    // Explicitly include routes that might have redirection logic for logged-in users
    // or need protection.
    '/dashboard/:path*',
    '/bereiche/:path*',
    '/einstellungen/:path*',
    '/login',
  ],
};
